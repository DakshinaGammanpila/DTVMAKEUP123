-- DTV Makeup Roster - Supabase Database Schema Setup
-- Database Solution for TV Derana Makeup Department

-- 1. Create Profiles Table (Team Members)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'Makeup Department Member',
    is_admin BOOLEAN NOT NULL DEFAULT FALSE,
    avatar_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public profiles are viewable by everyone" 
ON public.profiles FOR SELECT USING (true);

CREATE POLICY "Admins can update profiles" 
ON public.profiles FOR UPDATE USING (auth.uid() IN (SELECT id FROM public.profiles WHERE is_admin = true));

-- 2. Create Rosters Table
CREATE TABLE IF NOT EXISTS public.rosters (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    week_start_date DATE NOT NULL,
    title TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    published_by UUID REFERENCES public.profiles(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.rosters ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Rosters are viewable by authenticated users" 
ON public.rosters FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Only Admins can modify rosters" 
ON public.rosters FOR ALL USING (auth.uid() IN (SELECT id FROM public.profiles WHERE is_admin = true));

-- 3. Create Shifts Table
CREATE TABLE IF NOT EXISTS public.shifts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    roster_id UUID REFERENCES public.rosters(id) ON DELETE CASCADE,
    member_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    shift_date DATE NOT NULL,
    shift_type TEXT NOT NULL,
    programme_name TEXT,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.shifts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Shifts are viewable by authenticated users" 
ON public.shifts FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Only Admins can assign shifts" 
ON public.shifts FOR ALL USING (auth.uid() IN (SELECT id FROM public.profiles WHERE is_admin = true));

-- 4. Create Work Archive Table
CREATE TABLE IF NOT EXISTS public.work_archive (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    artist_name TEXT NOT NULL,
    image_url TEXT,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.work_archive ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Work archive is viewable by everyone" 
ON public.work_archive FOR SELECT USING (true);
