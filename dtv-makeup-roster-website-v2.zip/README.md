# DTV Makeup Roster Website - Complete Deployment Package

Official web portal and roster management system for the **TV Derana Makeup Department**.

## 📁 Package Contents

* `index.html` - Main modular web entry point.
* `index-standalone.html` - All-in-one single file (HTML + CSS + JS embedded) for instant 1-click preview.
* `css/styles.css` - Luxury Rose Gold & Deep Mahogany styling sheet.
* `js/app.js` - Dynamic roster engine, shift filtering, authentication, and portfolio logic.
* `supabase-setup.sql` - Complete PostgreSQL database schema with Row-Level Security (RLS) policies.
* `README.md` - Deployment documentation.

## 👥 Team Structure

* **Udayanga Kamaljith** — Head of Department
* **Amila Dilruksha** — Makeup Department Member
* **Buddika Nuwan** — Makeup Department Member
* **Zhara De Silva** — Makeup Department Member
* **Dakshina Gammanpila** — Makeup Department Member
* **Yashodara Niyomali** — Makeup Department Member

## 🚀 How to Host for Free

### Option 1: Netlify (Easiest - 1 Minute)
1. Go to Netlify Drop (https://app.netlify.com/drop).
2. Drag and drop the unzipped folder containing `index.html`, `css/`, and `js/`.
3. Netlify will generate your free live URL immediately!

### Option 2: Cloudflare Pages
1. Log in to your free Cloudflare account.
2. Navigate to Workers & Pages > Create application > Pages > Upload assets.
3. Upload the unzipped website folder and click Deploy.

### Option 3: GitHub Pages
1. Create a new public repository on GitHub (e.g., dtv-makeup-roster).
2. Push all files from this zip to the main branch.
3. Go to Settings > Pages > Select main branch as source > Click Save.

## 🗄️ Database Setup (Supabase Free Tier)

1. Create a free project on Supabase (https://supabase.com).
2. Go to SQL Editor in your Supabase dashboard.
3. Paste the contents of `supabase-setup.sql` and click Run.
4. Copy your Supabase Project URL and Anon Key into `js/app.js` to enable real-time database sync.
